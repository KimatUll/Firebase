// ----------- SignUp ----------------

const signup_form = document.querySelector('#signup_form')
signup_form.addEventListener ('submit', (e) => {
  e.preventDefault();
  const email = document.querySelector('#email').value;
  const password = document.querySelector('#password').value;

  firebase.auth().createUserWithEmailAndPassword(email, password)
  .then((user) => {
    // Signed in
    // ...
  })  
  .catch((error) => {
    var errorCode = error.code;
    var errorMessage = error.message;
    // ..
  });
})

// --------------- Login ------------


// Google Login

const googlebutton = document.querySelector('#googlelogin')
googlebutton.addEventListener('click', e => {
  const provider = new firebase.auth.GoogleAuthProvider();
  auth.signInWithPopup(provider)
  .then(result => {
    console.log('GOOGLE LOGIN!')
  })
  .catch((error) => {
    var errorCode = error.code;
    var errorMessage = error.message;
  })
});

// Facebook Login

const facebookbutton = document.querySelector('#facebooklogin')
facebookbutton.addEventListener('click', e => {
  e.preventDefault();
  const provider = new firebase.auth.FacebookAuthProvider();
  auth.signInWithPopup(provider)
  .then(result => {
     console.log('FACEBOOK LOGIN!')
  })
  .catch((error) => {
    var errorCode = error.code;
    var errorMessage = error.message;
  })
});

// Log Out 

const logout = document.querySelector('#log_Out');

logout.addEventListener('click', e => {
  e.preventDefault();
  auth.signOut().then(() => {
    console.log('Loged OUT!')
  })
})

// Posts 
const postslist = document.querySelector('.posts');
const setupPost = data => {
  if (data.length) {
    let html = '';
    data.forEach(doc => {
     const post = doc.data()
      console.log(post)
      const li = `
      <li class="list-group-item list-group-item-action">
        <h5>${post.title}</h5>
        <p>${post.description}</p>
      </li>
      `;
      html += li;
    });
    postslist.innerHTML = html;
  }
  else{
    postslist.innerHTML = '<p class="text-center"> Login to see data!</p>'
  }
}
// Events
// Auth state changes list

firebase.auth().onAuthStateChanged(user => {
  if (user) {
    // User is signed in, see docs for a list of available properties
    // https://firebase.google.com/docs/reference/js/firebase.User
    console.log(' you are in!');

    fs.collection('posts')
    .get()
    .then((snapshot) => {
      console.log(snapshot.docs);
      setupPost(snapshot.docs);
    })
    // ...
  } else {
    // User is signed out
    // ...
    console.log('you are not in :(')
    setupPost([]);
  }
});

/* firebase.auth().createUserWithEmailAndPassword(email, password)
  .then((user) => {
    // Signed in
    // ...
  })
  .catch((error) => {
    var errorCode = error.code;
    var errorMessage = error.message;
    // ..
  });
}
 /* firebase.auth().signInWithEmailAndPassword(email, password)
  .then((user) => {
    // Signed in
    // ...
  })
  .catch((error) => {
    var errorCode = error.code;
    var errorMessage = error.message;
  });

  firebase.auth().onAuthStateChanged((user) => {
    if (user) {
      // User is signed in, see docs for a list of available properties
      // https://firebase.google.com/docs/reference/js/firebase.User
      var uid = user.uid;
      // ...
    } else {
      // User is signed out
      // ...
    }
  });


var ui = new firebaseui.auth.AuthUI(firebase.auth());

var uiConfig = {
  callbacks: 
  {
    signInSuccessWithAuthResult: function(authResult, redirectUrl) 
    { return true; },
    uiShown: function() 
    { document.getElementById('loader').style.display = 'none';}
  }
  ,
  signInFlow: 'popup',
  signInSuccessUrl: '<url-to-redirect-to-on-success>',
  signInOptions: [
    // Leave the lines as is for the providers you want to offer your users.
    firebase.auth.GoogleAuthProvider.PROVIDER_ID,
    firebase.auth.FacebookAuthProvider.PROVIDER_ID,
    firebase.auth.TwitterAuthProvider.PROVIDER_ID,
    firebase.auth.GithubAuthProvider.PROVIDER_ID,
    firebase.auth.EmailAuthProvider.PROVIDER_ID,
    firebase.auth.PhoneAuthProvider.PROVIDER_ID
  ],
  tosUrl: '<your-tos-url>',
  privacyPolicyUrl: '<your-privacy-policy-url>'
};

ui.start('#firebaseui-auth-container', uiConfig);

if (ui.isPendingRedirect()) {
  ui.start('#firebaseui-auth-container', uiConfig);
}

var firebaseConfig = {
    apiKey: "AIzaSyAsGk5SOJZrKJQgVfdxOe1IWtvbCJFjzvc",
    authDomain: "aps2-80dba.firebaseapp.com",
    projectId: "aps2-80dba",
    storageBucket: "aps2-80dba.appspot.com",
    messagingSenderId: "128454218662",
    appId: "1:128454218662:web:a604c3f390837482fff567",
    measurementId: "G-44CSM358Z5"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics(); */
